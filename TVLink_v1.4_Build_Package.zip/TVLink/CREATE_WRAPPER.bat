@echo off
setlocal
cd /d "%~dp0"
echo This script requires a working system Gradle command.
gradle wrapper --gradle-version 8.9
if errorlevel 1 (
  echo.
  echo Wrapper generation failed. Open this folder in Android Studio and use its Gradle installation, or install Gradle 8.9.
  exit /b 1
)
echo Wrapper files generated. Now run: gradlew.bat assembleDebug
