@echo off
setlocal
cd /d "%~dp0"
echo ==========================================
echo TVLink v1.4 - Debug APK Builder
echo ==========================================
where java >nul 2>nul
if errorlevel 1 (
  echo ERROR: Java is not in PATH. Install JDK 17 and set JAVA_HOME.
  pause
  exit /b 1
)
if not exist "%ANDROID_HOME%\platforms\android-35\android.jar" (
  echo ERROR: Android SDK Platform 35 not found.
  echo Set ANDROID_HOME to your Android SDK folder.
  pause
  exit /b 1
)
echo.
echo Building TVLink v1.4 Debug APK...
call gradlew.bat --no-daemon clean assembleDebug
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Copy the complete error text and send it for diagnosis.
  pause
  exit /b 1
)
if not exist "app\build\outputs\apk\debug\app-debug.apk" (
  echo ERROR: Gradle ended but APK file was not found.
  pause
  exit /b 1
)
copy /y "app\build\outputs\apk\debug\app-debug.apk" "%~dp0TVLink-v1.4-debug.apk" >nul
echo.
echo BUILD SUCCESSFUL.
echo APK: %~dp0TVLink-v1.4-debug.apk
pause
